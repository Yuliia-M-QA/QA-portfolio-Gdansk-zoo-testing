import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
    // open home page of Gdansk zoo
  await page.goto('https://zoo.gdansk.pl/en/homepage/');
    // accept cookies
  await page.getByRole('button', { name: 'Zgadzam się' }).click();
    // change language to Polish
  await page.getByRole('link', { name: 'pl' }).click();
    // navigate to 'Wizyta w ZOO'
  await page.locator('#menu-item-39').getByRole('link', { name: 'Wizyta w ZOO' }).click();
    // click on 'male zoo' link
    // await page.getByTitle('Małe Zoo').click();
    await page.getByRole('link', { name: 'Małe Zoo' }).click();
    test('some test', async ({ page }) => {
  // твій код
}, { timeout: 60000 }); // 60 секунд


});